package handlers

import (
	"html/template"
	"net/http"
	"path/filepath"
)

type WebHandler struct {
	templates map[string]*template.Template
}

func NewWebHandler(templateDir string) (*WebHandler, error) {
	templates := make(map[string]*template.Template)

	// Cargar templates
	layout := filepath.Join(templateDir, "layout.html")

	pages := []string{"index.html", "login.html", "books.html", "search.html"}

	for _, page := range pages {
		tmpl, err := template.ParseFiles(layout, filepath.Join(templateDir, page))
		if err != nil {
			return nil, err
		}
		templates[page] = tmpl
	}

	return &WebHandler{templates: templates}, nil
}

func (wh *WebHandler) ServeIndex(w http.ResponseWriter, r *http.Request) {
	data := map[string]interface{}{
		"Title": "Sistema de Gestión de Libros",
		"User":  nil, // Aquí iría la información del usuario
	}

	if tmpl, ok := wh.templates["index.html"]; ok {
		tmpl.Execute(w, data)
	} else {
		http.Error(w, "Template no encontrado", http.StatusInternalServerError)
	}
}

func (wh *WebHandler) ServeLogin(w http.ResponseWriter, r *http.Request) {
	data := map[string]interface{}{
		"Title": "Iniciar Sesión",
	}

	if tmpl, ok := wh.templates["login.html"]; ok {
		tmpl.Execute(w, data)
	} else {
		http.Error(w, "Template no encontrado", http.StatusInternalServerError)
	}
}

func (wh *WebHandler) ServeBooks(w http.ResponseWriter, r *http.Request) {
	data := map[string]interface{}{
		"Title": "Catálogo de Libros",
	}

	if tmpl, ok := wh.templates["books.html"]; ok {
		tmpl.Execute(w, data)
	} else {
		http.Error(w, "Template no encontrado", http.StatusInternalServerError)
	}
}
