package handlers

import (
	"ebook-management-system/models"
	"ebook-management-system/services"
	"encoding/json"
	"net/http"
)

type AuthHandler struct {
	authService     *services.AuthService
	activityService *services.ActivityService
}

func NewAuthHandler() *AuthHandler {
	return &AuthHandler{
		authService:     services.GetAuthService(),
		activityService: services.GetActivityService(),
	}
}

func (ah *AuthHandler) Login(w http.ResponseWriter, r *http.Request) {
	var credentials struct {
		Email    string `json:"email"`
		Password string `json:"password"`
	}

	if err := json.NewDecoder(r.Body).Decode(&credentials); err != nil {
		http.Error(w, "Datos inválidos", http.StatusBadRequest)
		return
	}

	user, err := ah.authService.Authenticate(credentials.Email, credentials.Password)
	if err != nil {
		http.Error(w, err.Error(), http.StatusUnauthorized)
		return
	}

	// Registrar actividad
	activity := models.NewActivity(user.ID, models.ActivityLogin, "Inicio de sesión exitoso")
	ah.activityService.LogActivity(activity)

	response := map[string]interface{}{
		"message": "Login exitoso",
		"user": map[string]interface{}{
			"id":    user.ID,
			"email": user.Email,
			"name":  user.Name,
			"role":  user.Role,
		},
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)
}

func (ah *AuthHandler) Register(w http.ResponseWriter, r *http.Request) {
	var userData struct {
		Email    string      `json:"email"`
		Password string      `json:"password"`
		Name     string      `json:"name"`
		Role     models.Role `json:"role"`
	}

	if err := json.NewDecoder(r.Body).Decode(&userData); err != nil {
		http.Error(w, "Datos inválidos", http.StatusBadRequest)
		return
	}

	// Solo administradores pueden crear otros administradores
	// (aquí se agregaría verificación de token JWT en producción)

	user, err := models.NewUser(userData.Email, userData.Password, userData.Name, models.RoleReader)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	if err := ah.authService.Register(user); err != nil {
		http.Error(w, err.Error(), http.StatusConflict)
		return
	}

	// Registrar actividad
	activity := models.NewActivity(user.ID, models.ActivityCreateUser, "Usuario creado: "+user.Email)
	ah.activityService.LogActivity(activity)

	response := map[string]interface{}{
		"message": "Usuario registrado exitosamente",
		"user_id": user.ID,
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusCreated)
	json.NewEncoder(w).Encode(response)
}
