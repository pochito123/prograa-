package handlers

import (
	"ebook-management-system/models"
	"ebook-management-system/services"
	"encoding/json"
	"net/http"
	"strconv"
)

type BookHandler struct {
	bookService     *services.BookService
	storageService  *services.StorageService
	searchService   *services.SearchService
	authService     *services.AuthService
	activityService *services.ActivityService
}

func NewBookHandler(storagePath string) (*BookHandler, error) {
	storageService, err := services.NewStorageService(storagePath)
	if err != nil {
		return nil, err
	}

	bookService := services.GetBookService()
	authService := services.GetAuthService()
	activityService := services.GetActivityService()
	searchService := services.NewSearchService(bookService)

	return &BookHandler{
		bookService:     bookService,
		storageService:  storageService,
		searchService:   searchService,
		authService:     authService,
		activityService: activityService,
	}, nil
}

func (bh *BookHandler) CreateBook(w http.ResponseWriter, r *http.Request) {
	// Aquí se verificaría el token JWT en producción

	var bookData struct {
		Title       string   `json:"title"`
		Author      string   `json:"author"`
		Description string   `json:"description"`
		Language    string   `json:"language"`
		Tags        []string `json:"tags"`
		FileName    string   `json:"file_name"`
		FileContent string   `json:"file_content"` // Base64 en producción
	}

	if err := json.NewDecoder(r.Body).Decode(&bookData); err != nil {
		http.Error(w, "Datos inválidos", http.StatusBadRequest)
		return
	}

	// Crear libro
	book, err := models.NewBook(
		bookData.Title,
		bookData.Author,
		bookData.Description,
		bookData.Language,
		bookData.FileName,
		bookData.Tags,
	)
	if err != nil {
		http.Error(w, err.Error(), http.StatusBadRequest)
		return
	}

	// Guardar en servicio de libros
	if err := bh.bookService.CreateBook(book); err != nil {
		http.Error(w, err.Error(), http.StatusConflict)
		return
	}

	// Aquí se guardaría el archivo en producción
	// fileContent, _ := base64.StdEncoding.DecodeString(bookData.FileContent)
	// bh.storageService.SaveFile(book.ID, bookData.FileName, fileContent)

	// Registrar actividad
	// activity := models.NewActivity(userID, models.ActivityUpload, "Libro subido: " + book.Title)
	// bh.activityService.LogActivity(activity)

	response := map[string]interface{}{
		"message": "Libro creado exitosamente",
		"book_id": book.ID,
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusCreated)
	json.NewEncoder(w).Encode(response)
}

func (bh *BookHandler) GetBooks(w http.ResponseWriter, r *http.Request) {
	books := bh.bookService.GetAllBooks()

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(books)
}

func (bh *BookHandler) SearchBooks(w http.ResponseWriter, r *http.Request) {
	query := r.URL.Query().Get("q")
	searchType := r.URL.Query().Get("type")

	var results []*models.Book

	switch searchType {
	case "author":
		results = bh.searchService.SearchByAuthor(query)
	case "tag":
		results = bh.searchService.SearchByTag(query)
	default:
		results = bh.searchService.Search(query)
	}

	// Paginación
	page, _ := strconv.Atoi(r.URL.Query().Get("page"))
	limit, _ := strconv.Atoi(r.URL.Query().Get("limit"))

	if page < 1 {
		page = 1
	}
	if limit < 1 || limit > 100 {
		limit = 10
	}

	start := (page - 1) * limit
	end := start + limit

	if start >= len(results) {
		results = []*models.Book{}
	} else if end > len(results) {
		results = results[start:]
	} else {
		results = results[start:end]
	}

	response := map[string]interface{}{
		"page":    page,
		"limit":   limit,
		"total":   len(bh.bookService.GetAllBooks()),
		"results": results,
	}

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(response)
}
