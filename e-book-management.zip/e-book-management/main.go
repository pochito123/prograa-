package main

import (
	"context"
	"fmt"
	"log"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/gorilla/mux"

	"ebook-management-system/handlers"
	"ebook-management-system/utils"
)

func main() {
	fmt.Println("=== Sistema de Gestión de Libros Electrónicos ===")
	fmt.Println("Universidad Internacional del Ecuador (UIDE)")
	fmt.Println("Programación Orientada a Objetos")
	fmt.Println("Estudiantes: Jimmy Herrera, Marcos Cumbajin")
	fmt.Println("=================================================")

	// Inicializar sistema
	if err := utils.InitSystem(); err != nil {
		log.Fatal("Error inicializando sistema:", err)
	}

	// Cargar configuración
	config := utils.LoadConfig("config.json")

	// Inicializar logger
	logger, err := utils.NewLogger("logs/system.log")
	if err != nil {
		log.Fatal("Error inicializando logger:", err)
	}
	defer logger.Close()

	logger.Log("INFO", "Sistema iniciado")

	// Inicializar handlers
	bookHandler, err := handlers.NewBookHandler(config.StoragePath)
	if err != nil {
		logger.Log("ERROR", "Error inicializando book handler: "+err.Error())
		log.Fatal("Error inicializando book handler:", err)
	}

	authHandler := handlers.NewAuthHandler()

	// Configurar router
	router := mux.NewRouter()

	// Middleware de logging
	router.Use(func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			start := time.Now()

			// Crear respuesta wrapper para capturar status code
			rw := &responseWriter{ResponseWriter: w, statusCode: http.StatusOK}

			next.ServeHTTP(rw, r)

			duration := time.Since(start)
			logger.Log("REQUEST", fmt.Sprintf("%s %s %d %v", r.Method, r.URL.Path, rw.statusCode, duration))
		})
	})

	// Rutas de API
	api := router.PathPrefix("/api").Subrouter()

	// Autenticación
	api.HandleFunc("/login", authHandler.Login).Methods("POST")
	api.HandleFunc("/register", authHandler.Register).Methods("POST")

	// Libros
	api.HandleFunc("/books", bookHandler.CreateBook).Methods("POST")
	api.HandleFunc("/books", bookHandler.GetBooks).Methods("GET")
	api.HandleFunc("/books/search", bookHandler.SearchBooks).Methods("GET")
	api.HandleFunc("/books/{id}", func(w http.ResponseWriter, r *http.Request) {
		vars := mux.Vars(r)
		fmt.Fprintf(w, "Libro ID: %s", vars["id"])
	}).Methods("GET")

	// Rutas web
	webHandler, err := handlers.NewWebHandler("./templates")
	if err != nil {
		logger.Log("ERROR", "Error cargando templates: "+err.Error())
		log.Fatal("Error cargando templates:", err)
	}

	router.HandleFunc("/", webHandler.ServeIndex)
	router.HandleFunc("/login", webHandler.ServeLogin)
	router.HandleFunc("/books", webHandler.ServeBooks)

	// Servir archivos estáticos
	router.PathPrefix("/static/").Handler(http.StripPrefix("/static/",
		http.FileServer(http.Dir("./static"))))

	// Ruta de salud
	router.HandleFunc("/health", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		fmt.Fprintf(w, `{"status": "ok", "timestamp": "%s"}`, time.Now().Format(time.RFC3339))
	}).Methods("GET")

	// Configurar servidor
	server := &http.Server{
		Addr:         config.ServerPort,
		Handler:      router,
		ReadTimeout:  15 * time.Second,
		WriteTimeout: 15 * time.Second,
		IdleTimeout:  60 * time.Second,
	}

	// Canal para manejar señales de interrupción
	stopChan := make(chan os.Signal, 1)
	signal.Notify(stopChan, os.Interrupt, syscall.SIGTERM)

	// Goroutine para limpieza periódica
	go cleanupRoutine(logger)

	// Goroutine para mostrar información del sistema
	go systemInfoRoutine(logger)

	// Iniciar servidor en goroutine
	go func() {
		fmt.Printf("Servidor iniciado en http://localhost%s\n", config.ServerPort)
		fmt.Println("Endpoints disponibles:")
		fmt.Println("  GET  /api/books")
		fmt.Println("  POST /api/books")
		fmt.Println("  GET  /api/books/search")
		fmt.Println("  POST /api/login")
		fmt.Println("  POST /api/register")
		fmt.Println("  GET  /health")
		fmt.Println("\nPresiona Ctrl+C para detener el servidor")

		if err := server.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			logger.Log("ERROR", "Error del servidor: "+err.Error())
			log.Fatal("Error del servidor:", err)
		}
	}()

	// Esperar señal de interrupción
	<-stopChan
	logger.Log("INFO", "Recibida señal de apagado")

	// Apagar servidor graceful
	ctx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()

	if err := server.Shutdown(ctx); err != nil {
		logger.Log("ERROR", "Error apagando servidor: "+err.Error())
		log.Fatal("Error apagando servidor:", err)
	}

	logger.Log("INFO", "Servidor apagado correctamente")
	fmt.Println("\nServidor apagado correctamente")
}

// responseWriter wrapper para capturar status code
type responseWriter struct {
	http.ResponseWriter
	statusCode int
}

func (rw *responseWriter) WriteHeader(code int) {
	rw.statusCode = code
	rw.ResponseWriter.WriteHeader(code)
}

// cleanupRoutine realiza limpieza periódica
func cleanupRoutine(logger *utils.Logger) {
	ticker := time.NewTicker(1 * time.Hour)
	defer ticker.Stop()

	for range ticker.C {
		logger.Log("INFO", "Ejecutando limpieza periódica")
		// Aquí se llamarían métodos de limpieza de los servicios
	}
}

// systemInfoRoutine muestra información del sistema periódicamente
func systemInfoRoutine(logger *utils.Logger) {
	ticker := time.NewTicker(5 * time.Minute)
	defer ticker.Stop()

	for range ticker.C {
		// Obtener IP local
		if ip, err := utils.GetLocalIP(); err == nil {
			logger.Log("INFO", "IP local: "+ip)
		}
	}
}

// Ejecutar tests si se especifica
func init() {
	if len(os.Args) > 1 && os.Args[1] == "test" {
		fmt.Println("Ejecutando tests...")
		// Aquí se ejecutarían los tests automáticamente
		os.Exit(0)
	}

	if len(os.Args) > 1 && os.Args[1] == "init" {
		fmt.Println("Inicializando sistema...")
		if err := utils.InitSystem(); err != nil {
			fmt.Println("Error:", err)
			os.Exit(1)
		}
		fmt.Println("Sistema inicializado correctamente")
		os.Exit(0)
	}
}
