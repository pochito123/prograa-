package services

import (
	"ebook-management-system/models"
	"errors"
	"sync"
)

type BookService struct {
	books []*models.Book
	mu    sync.RWMutex
}

var bookServiceInstance *BookService
var bookOnce sync.Once

func GetBookService() *BookService {
	bookOnce.Do(func() {
		bookServiceInstance = &BookService{
			books: make([]*models.Book, 0),
		}
	})
	return bookServiceInstance
}

func (bs *BookService) CreateBook(book *models.Book) error {
	bs.mu.Lock()
	defer bs.mu.Unlock()

	// Verificar si el libro ya existe
	for _, b := range bs.books {
		if b.Title == book.Title && b.Author == book.Author {
			return errors.New("el libro ya existe")
		}
	}

	bs.books = append(bs.books, book)
	return nil
}

func (bs *BookService) GetBookByID(id string) (*models.Book, error) {
	bs.mu.RLock()
	defer bs.mu.RUnlock()

	for _, book := range bs.books {
		if book.ID == id && book.IsActive {
			return book, nil
		}
	}
	return nil, errors.New("libro no encontrado")
}

func (bs *BookService) GetAllBooks() []*models.Book {
	bs.mu.RLock()
	defer bs.mu.RUnlock()

	activeBooks := make([]*models.Book, 0)
	for _, book := range bs.books {
		if book.IsActive {
			activeBooks = append(activeBooks, book)
		}
	}
	return activeBooks
}

func (bs *BookService) UpdateBook(id string, updates map[string]interface{}) error {
	bs.mu.Lock()
	defer bs.mu.Unlock()

	for _, book := range bs.books {
		if book.ID == id {
			if title, ok := updates["title"].(string); ok && title != "" {
				book.Title = title
			}
			if author, ok := updates["author"].(string); ok && author != "" {
				book.Author = author
			}
			if description, ok := updates["description"].(string); ok {
				book.Description = description
			}
			if tags, ok := updates["tags"].([]string); ok {
				book.Tags = tags
			}
			return nil
		}
	}
	return errors.New("libro no encontrado")
}

func (bs *BookService) DeleteBook(id string) error {
	bs.mu.Lock()
	defer bs.mu.Unlock()

	for i, book := range bs.books {
		if book.ID == id {
			bs.books[i].IsActive = false
			return nil
		}
	}
	return errors.New("libro no encontrado")
}
