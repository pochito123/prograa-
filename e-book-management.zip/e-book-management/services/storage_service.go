package services

import (
	"errors"
	"os"
	"path/filepath"
	"strings"
	"sync"
)

type StorageService struct {
	storagePath string
	mu          sync.RWMutex
}

func NewStorageService(storagePath string) (*StorageService, error) {
	if err := os.MkdirAll(storagePath, 0755); err != nil {
		return nil, err
	}

	return &StorageService{
		storagePath: storagePath,
	}, nil
}

// Método con manejo de errores
func (ss *StorageService) SaveFile(bookID, fileName string, fileContent []byte) (string, error) {
	ss.mu.Lock()
	defer ss.mu.Unlock()

	if len(fileContent) == 0 {
		return "", errors.New("contenido del archivo vacío")
	}

	// Crear directorio para el libro
	bookDir := filepath.Join(ss.storagePath, bookID)
	if err := os.MkdirAll(bookDir, 0755); err != nil {
		return "", err
	}

	// Guardar archivo
	filePath := filepath.Join(bookDir, fileName)
	if err := os.WriteFile(filePath, fileContent, 0644); err != nil {
		return "", err
	}

	return filePath, nil
}

func (ss *StorageService) GetFile(bookID, fileName string) ([]byte, error) {
	ss.mu.RLock()
	defer ss.mu.RUnlock()

	filePath := filepath.Join(ss.storagePath, bookID, fileName)

	if _, err := os.Stat(filePath); os.IsNotExist(err) {
		return nil, errors.New("archivo no encontrado")
	}

	return os.ReadFile(filePath)
}

func (ss *StorageService) DeleteFile(bookID, fileName string) error {
	ss.mu.Lock()
	defer ss.mu.Unlock()

	filePath := filepath.Join(ss.storagePath, bookID, fileName)

	if _, err := os.Stat(filePath); os.IsNotExist(err) {
		return errors.New("archivo no encontrado")
	}

	return os.Remove(filePath)
}

// Goroutine para limpieza de archivos temporales
func (ss *StorageService) CleanTempFiles() <-chan string {
	resultChan := make(chan string)

	go func() {
		defer close(resultChan)

		ss.mu.Lock()
		defer ss.mu.Unlock()

		// Recorrer directorios
		dirs, err := os.ReadDir(ss.storagePath)
		if err != nil {
			resultChan <- "Error leyendo directorio: " + err.Error()
			return
		}

		for _, dir := range dirs {
			if dir.IsDir() {
				dirPath := filepath.Join(ss.storagePath, dir.Name())
				files, err := os.ReadDir(dirPath)
				if err != nil {
					continue
				}

				// Buscar archivos temporales
				for _, file := range files {
					if strings.HasSuffix(file.Name(), ".tmp") {
						filePath := filepath.Join(dirPath, file.Name())
						if err := os.Remove(filePath); err == nil {
							resultChan <- "Eliminado: " + filePath
						}
					}
				}
			}
		}
	}()

	return resultChan
}
