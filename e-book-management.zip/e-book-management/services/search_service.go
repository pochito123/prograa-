package services

import (
	"ebook-management-system/models"
	"strings"
	"sync"
)

// Interfaz para búsqueda
type Searchable interface {
	Search(query string) []*models.Book
}

type SearchService struct {
	bookService *BookService
	mu          sync.RWMutex
}

func NewSearchService(bs *BookService) *SearchService {
	return &SearchService{
		bookService: bs,
	}
}

// Polimorfismo: múltiples métodos de búsqueda
func (ss *SearchService) Search(query string) []*models.Book {
	ss.mu.RLock()
	defer ss.mu.RUnlock()

	books := ss.bookService.GetAllBooks()
	results := make([]*models.Book, 0)

	query = strings.ToLower(strings.TrimSpace(query))
	if query == "" {
		return books
	}

	for _, book := range books {
		if ss.matchesQuery(book, query) {
			results = append(results, book)
		}
	}

	return results
}

func (ss *SearchService) SearchByTitle(title string) []*models.Book {
	return ss.Search(title)
}

func (ss *SearchService) SearchByAuthor(author string) []*models.Book {
	ss.mu.RLock()
	defer ss.mu.RUnlock()

	books := ss.bookService.GetAllBooks()
	results := make([]*models.Book, 0)

	author = strings.ToLower(author)

	for _, book := range books {
		if strings.Contains(strings.ToLower(book.Author), author) {
			results = append(results, book)
		}
	}

	return results
}

func (ss *SearchService) SearchByTag(tag string) []*models.Book {
	ss.mu.RLock()
	defer ss.mu.RUnlock()

	books := ss.bookService.GetAllBooks()
	results := make([]*models.Book, 0)

	tag = strings.ToLower(tag)

	for _, book := range books {
		for _, bookTag := range book.Tags {
			if strings.Contains(strings.ToLower(bookTag), tag) {
				results = append(results, book)
				break
			}
		}
	}

	return results
}

// Método privado (encapsulación)
func (ss *SearchService) matchesQuery(book *models.Book, query string) bool {
	// Búsqueda en título
	if strings.Contains(strings.ToLower(book.Title), query) {
		return true
	}

	// Búsqueda en autor
	if strings.Contains(strings.ToLower(book.Author), query) {
		return true
	}

	// Búsqueda en tags
	for _, tag := range book.Tags {
		if strings.Contains(strings.ToLower(tag), query) {
			return true
		}
	}

	// Búsqueda en descripción
	if strings.Contains(strings.ToLower(book.Description), query) {
		return true
	}

	return false
}
