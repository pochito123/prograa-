package services

import (
	"ebook-management-system/models"
	"sync"
	"time"
)

type ActivityService struct {
	activities []*models.Activity
	mu         sync.RWMutex
}

var activityServiceInstance *ActivityService
var activityOnce sync.Once

func GetActivityService() *ActivityService {
	activityOnce.Do(func() {
		activityServiceInstance = &ActivityService{
			activities: make([]*models.Activity, 0),
		}
	})
	return activityServiceInstance
}

func (as *ActivityService) LogActivity(activity *models.Activity) {
	as.mu.Lock()
	defer as.mu.Unlock()

	as.activities = append(as.activities, activity)
}

func (as *ActivityService) GetUserActivities(userID string) []*models.Activity {
	as.mu.RLock()
	defer as.mu.RUnlock()

	userActivities := make([]*models.Activity, 0)
	for _, activity := range as.activities {
		if activity.UserID == userID {
			userActivities = append(userActivities, activity)
		}
	}
	return userActivities
}

func (as *ActivityService) GetAllActivities() []*models.Activity {
	as.mu.RLock()
	defer as.mu.RUnlock()

	return as.activities
}

// Goroutine para limpiar actividades antiguas
func (as *ActivityService) CleanOldActivities(days int) <-chan int {
	resultChan := make(chan int)

	go func() {
		defer close(resultChan)

		as.mu.Lock()
		defer as.mu.Unlock()

		cutOffTime := time.Now().AddDate(0, 0, -days)
		newActivities := make([]*models.Activity, 0)
		removedCount := 0

		for _, activity := range as.activities {
			if activity.Timestamp.After(cutOffTime) {
				newActivities = append(newActivities, activity)
			} else {
				removedCount++
			}
		}

		as.activities = newActivities
		resultChan <- removedCount
	}()

	return resultChan
}
