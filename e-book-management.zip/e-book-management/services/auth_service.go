package services

import (
	"ebook-management-system/models"
	"errors"
	"sync"
)

// Interfaz para autenticación
type Authenticator interface {
	Authenticate(email, password string) (*models.User, error)
	Register(user *models.User) error
}

type AuthService struct {
	users []*models.User
	mu    sync.RWMutex
}

// Implementación de Singleton
var authServiceInstance *AuthService
var authOnce sync.Once

func GetAuthService() *AuthService {
	authOnce.Do(func() {
		authServiceInstance = &AuthService{
			users: make([]*models.User, 0),
		}
		// Crear usuario admin por defecto
		admin, _ := models.NewUser("admin@system.com", "admin123", "Administrador", models.RoleAdmin)
		authServiceInstance.users = append(authServiceInstance.users, admin)
	})
	return authServiceInstance
}

func (as *AuthService) Authenticate(email, password string) (*models.User, error) {
	as.mu.RLock()
	defer as.mu.RUnlock()

	// Uso de bucles y condicionales
	for _, user := range as.users {
		if user.Email == email && user.IsActive {
			if user.CheckPassword(password) {
				return user, nil
			}
		}
	}
	return nil, errors.New("credenciales inválidas")
}

func (as *AuthService) Register(user *models.User) error {
	as.mu.Lock()
	defer as.mu.Unlock()

	// Verificar si el usuario ya existe
	for _, u := range as.users {
		if u.Email == user.Email {
			return errors.New("el usuario ya existe")
		}
	}

	as.users = append(as.users, user)
	return nil
}

func (as *AuthService) GetUserByID(id string) (*models.User, error) {
	as.mu.RLock()
	defer as.mu.RUnlock()

	for _, user := range as.users {
		if user.ID == id {
			return user, nil
		}
	}
	return nil, errors.New("usuario no encontrado")
}

func (as *AuthService) GetAllUsers() []*models.User {
	as.mu.RLock()
	defer as.mu.RUnlock()

	return as.users
}

func (as *AuthService) UpdateUser(userID string, updates map[string]interface{}) error {
	as.mu.Lock()
	defer as.mu.Unlock()

	for _, user := range as.users {
		if user.ID == userID {
			if name, ok := updates["name"].(string); ok && name != "" {
				user.Name = name
			}
			if isActive, ok := updates["is_active"].(bool); ok {
				user.IsActive = isActive
			}
			return nil
		}
	}
	return errors.New("usuario no encontrado")
}
