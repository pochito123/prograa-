package utils

import (
	"compress/gzip"
	"crypto/aes"
	"crypto/cipher"
	"crypto/rand"
	"encoding/base64"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"log"
	"net"
	"os"
	"path/filepath"
	"regexp"
	"strconv"
	"strings"
	"sync"
	"time"
)

// ============================================
// MANEJO DE CONCURRENCIA
// ============================================

// WorkerPool implementa un pool de trabajadores concurrentes
type WorkerPool struct {
	workers int
	tasks   chan func()
	wg      sync.WaitGroup
}

// NewWorkerPool crea un nuevo pool de trabajadores
func NewWorkerPool(workers int) *WorkerPool {
	pool := &WorkerPool{
		workers: workers,
		tasks:   make(chan func()),
	}

	pool.wg.Add(workers)
	for i := 0; i < workers; i++ {
		go pool.worker()
	}

	return pool
}

func (wp *WorkerPool) worker() {
	defer wp.wg.Done()
	for task := range wp.tasks {
		task()
	}
}

func (wp *WorkerPool) Submit(task func()) {
	wp.tasks <- task
}

func (wp *WorkerPool) Wait() {
	close(wp.tasks)
	wp.wg.Wait()
}

// ============================================
// MANEJO DE ARCHIVOS
// ============================================

// FileInfo contiene información de archivos
type FileInfo struct {
	Name      string    `json:"name"`
	Size      int64     `json:"size"`
	Modified  time.Time `json:"modified"`
	IsDir     bool      `json:"is_dir"`
	Extension string    `json:"extension"`
}

// GetFilesInDirectory obtiene todos los archivos en un directorio (concurrente)
func GetFilesInDirectory(dirPath string) ([]FileInfo, error) {
	entries, err := os.ReadDir(dirPath)
	if err != nil {
		return nil, err
	}

	files := make([]FileInfo, 0, len(entries))
	var mu sync.Mutex
	var wg sync.WaitGroup

	for _, entry := range entries {
		wg.Add(1)
		go func(e os.DirEntry) {
			defer wg.Done()

			info, err := e.Info()
			if err != nil {
				return
			}

			fileInfo := FileInfo{
				Name:      e.Name(),
				Size:      info.Size(),
				Modified:  info.ModTime(),
				IsDir:     e.IsDir(),
				Extension: filepath.Ext(e.Name()),
			}

			mu.Lock()
			files = append(files, fileInfo)
			mu.Unlock()
		}(entry)
	}

	wg.Wait()
	return files, nil
}

// SafeWriteFile escribe un archivo de manera segura con respaldo
func SafeWriteFile(filename string, data []byte, perm os.FileMode) error {
	// Primero escribimos a un archivo temporal
	tempFile := filename + ".tmp"

	if err := os.WriteFile(tempFile, data, perm); err != nil {
		return err
	}

	// Luego renombramos al nombre final (operación atómica)
	if err := os.Rename(tempFile, filename); err != nil {
		// Limpiar archivo temporal si hay error
		os.Remove(tempFile)
		return err
	}

	return nil
}

// ============================================
// VALIDACIONES
// ============================================

// Validators es una interfaz para validaciones
type Validator interface {
	Validate() error
}

// EmailValidator valida emails
type EmailValidator struct {
	Email string
}

func (ev EmailValidator) Validate() error {
	pattern := `^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$`
	match, _ := regexp.MatchString(pattern, ev.Email)
	if !match {
		return errors.New("email inválido")
	}
	return nil
}

// PasswordValidator valida contraseñas
type PasswordValidator struct {
	Password string
}

func (pv PasswordValidator) Validate() error {
	if len(pv.Password) < 6 {
		return errors.New("la contraseña debe tener al menos 6 caracteres")
	}

	// Verificar que tenga al menos un número
	hasNumber := false
	for _, char := range pv.Password {
		if char >= '0' && char <= '9' {
			hasNumber = true
			break
		}
	}

	if !hasNumber {
		return errors.New("la contraseña debe contener al menos un número")
	}

	return nil
}

// Polimorfismo: función que acepta cualquier validador
func ValidateAll(validators ...Validator) []error {
	var errors []error

	for _, validator := range validators {
		if err := validator.Validate(); err != nil {
			errors = append(errors, err)
		}
	}

	return errors
}

// ============================================
// ENCRIPTACIÓN
// ============================================

// Encrypt cifra datos usando AES
func Encrypt(data []byte, key string) (string, error) {
	block, err := aes.NewCipher([]byte(padKey(key)))
	if err != nil {
		return "", err
	}

	// El IV debe ser único para cada cifrado
	ciphertext := make([]byte, aes.BlockSize+len(data))
	iv := ciphertext[:aes.BlockSize]
	if _, err := io.ReadFull(rand.Reader, iv); err != nil {
		return "", err
	}

	stream := cipher.NewCFBEncrypter(block, iv)
	stream.XORKeyStream(ciphertext[aes.BlockSize:], data)

	return base64.StdEncoding.EncodeToString(ciphertext), nil
}

// Decrypt descifra datos usando AES
func Decrypt(encrypted string, key string) ([]byte, error) {
	ciphertext, err := base64.StdEncoding.DecodeString(encrypted)
	if err != nil {
		return nil, err
	}

	block, err := aes.NewCipher([]byte(padKey(key)))
	if err != nil {
		return nil, err
	}

	if len(ciphertext) < aes.BlockSize {
		return nil, errors.New("ciphertext demasiado corto")
	}

	iv := ciphertext[:aes.BlockSize]
	ciphertext = ciphertext[aes.BlockSize:]

	stream := cipher.NewCFBDecrypter(block, iv)
	stream.XORKeyStream(ciphertext, ciphertext)

	return ciphertext, nil
}

func padKey(key string) string {
	// Asegurar que la clave tenga 16, 24 o 32 bytes
	keyBytes := []byte(key)
	desiredLength := 32 // AES-256

	if len(keyBytes) > desiredLength {
		return string(keyBytes[:desiredLength])
	}

	// Rellenar si es necesario
	for len(keyBytes) < desiredLength {
		keyBytes = append(keyBytes, '0')
	}

	return string(keyBytes)
}

// ============================================
// COMPRESIÓN
// ============================================

// CompressData comprime datos usando gzip
func CompressData(data []byte) ([]byte, error) {
	var buf strings.Builder
	writer, _ := gzip.NewWriterLevel(&buf, gzip.BestCompression)

	if _, err := writer.Write(data); err != nil {
		return nil, err
	}

	if err := writer.Close(); err != nil {
		return nil, err
	}

	return []byte(buf.String()), nil
}

// DecompressData descomprime datos gzip
func DecompressData(compressed []byte) ([]byte, error) {
	reader, err := gzip.NewReader(strings.NewReader(string(compressed)))
	if err != nil {
		return nil, err
	}
	defer reader.Close()

	return io.ReadAll(reader)
}

// ============================================
// LOGGING
// ============================================

// Logger maneja registro de eventos
type Logger struct {
	logFile *os.File
	mu      sync.Mutex
}

// NewLogger crea un nuevo logger
func NewLogger(filename string) (*Logger, error) {
	file, err := os.OpenFile(filename, os.O_CREATE|os.O_WRONLY|os.O_APPEND, 0666)
	if err != nil {
		return nil, err
	}

	return &Logger{logFile: file}, nil
}

// Log registra un mensaje
func (l *Logger) Log(level, message string) {
	l.mu.Lock()
	defer l.mu.Unlock()

	timestamp := time.Now().Format("2006-01-02 15:04:05")
	logEntry := fmt.Sprintf("[%s] %s: %s\n", timestamp, strings.ToUpper(level), message)

	// Escribir en archivo
	l.logFile.WriteString(logEntry)

	// También mostrar en consola
	log.Print(logEntry)
}

// LogActivity registra una actividad específica
func (l *Logger) LogActivity(userID, action, details string) {
	message := fmt.Sprintf("Usuario %s: %s - %s", userID, action, details)
	l.Log("ACTIVITY", message)
}

// Close cierra el logger
func (l *Logger) Close() {
	l.logFile.Close()
}

// ============================================
// MANEJO DE CONFIGURACIÓN
// ============================================

// Config almacena configuración del sistema
type Config struct {
	ServerPort   string   `json:"server_port"`
	StoragePath  string   `json:"storage_path"`
	MaxFileSize  int64    `json:"max_file_size"`
	AllowedTypes []string `json:"allowed_types"`
	LogLevel     string   `json:"log_level"`
}

var (
	configInstance *Config
	configOnce     sync.Once
	configMu       sync.RWMutex
)

// LoadConfig carga la configuración (Singleton)
func LoadConfig(configFile string) *Config {
	configOnce.Do(func() {
		configInstance = &Config{
			ServerPort:   ":8080",
			StoragePath:  "./storage",
			MaxFileSize:  10 * 1024 * 1024, // 10MB
			AllowedTypes: []string{".pdf", ".epub", ".mobi"},
			LogLevel:     "info",
		}

		// Intentar cargar desde archivo
		if data, err := os.ReadFile(configFile); err == nil {
			json.Unmarshal(data, configInstance)
		}
	})

	return configInstance
}

// GetConfig obtiene la configuración actual
func GetConfig() *Config {
	configMu.RLock()
	defer configMu.RUnlock()

	return configInstance
}

// UpdateConfig actualiza la configuración
func UpdateConfig(updates map[string]interface{}) error {
	configMu.Lock()
	defer configMu.Unlock()

	if configInstance == nil {
		return errors.New("configuración no inicializada")
	}

	// Usar reflexión o mapeo manual para actualizar
	// (simplificado para el ejemplo)
	return nil
}

// ============================================
// UTILIDADES DE CADENA
// ============================================

// Slugify convierte un string en un slug URL-friendly
func Slugify(s string) string {
	// Convertir a minúsculas
	s = strings.ToLower(s)

	// Reemplazar caracteres especiales
	replacements := map[string]string{
		"á": "a", "é": "e", "í": "i", "ó": "o", "ú": "u",
		"ñ": "n", "ü": "u",
		" ": "-", "_": "-", ".": "-",
	}

	for old, new := range replacements {
		s = strings.ReplaceAll(s, old, new)
	}

	// Remover caracteres no alfanuméricos
	var result strings.Builder
	for _, r := range s {
		if (r >= 'a' && r <= 'z') || (r >= '0' && r <= '9') || r == '-' {
			result.WriteRune(r)
		}
	}

	// Eliminar guiones múltiples
	slug := result.String()
	for strings.Contains(slug, "--") {
		slug = strings.ReplaceAll(slug, "--", "-")
	}

	// Eliminar guiones al inicio y final
	slug = strings.Trim(slug, "-")

	return slug
}

// Truncate trunca un string a una longitud máxima
func Truncate(s string, maxLength int) string {
	if len(s) <= maxLength {
		return s
	}

	if maxLength > 3 {
		return s[:maxLength-3] + "..."
	}

	return s[:maxLength]
}

// ============================================
// MANEJO DE FECHAS
// ============================================

// ParseDate parsea una fecha en varios formatos
func ParseDate(dateStr string) (time.Time, error) {
	formats := []string{
		"2006-01-02",
		"02/01/2006",
		"January 2, 2006",
		time.RFC3339,
	}

	for _, format := range formats {
		if t, err := time.Parse(format, dateStr); err == nil {
			return t, nil
		}
	}

	return time.Time{}, errors.New("formato de fecha no reconocido")
}

// FormatDuration formatea una duración en texto legible
func FormatDuration(d time.Duration) string {
	days := int(d.Hours() / 24)
	hours := int(d.Hours()) % 24
	minutes := int(d.Minutes()) % 60
	seconds := int(d.Seconds()) % 60

	parts := []string{}

	if days > 0 {
		parts = append(parts, fmt.Sprintf("%d días", days))
	}
	if hours > 0 {
		parts = append(parts, fmt.Sprintf("%d horas", hours))
	}
	if minutes > 0 {
		parts = append(parts, fmt.Sprintf("%d minutos", minutes))
	}
	if seconds > 0 || len(parts) == 0 {
		parts = append(parts, fmt.Sprintf("%d segundos", seconds))
	}

	return strings.Join(parts, ", ")
}

// ============================================
// MANEJO DE ERRORES
// ============================================

// AppError es un error personalizado para la aplicación
type AppError struct {
	Code    string `json:"code"`
	Message string `json:"message"`
	Details string `json:"details,omitempty"`
	Err     error  `json:"-"`
}

func (ae *AppError) Error() string {
	if ae.Err != nil {
		return fmt.Sprintf("%s: %s (%s)", ae.Code, ae.Message, ae.Err.Error())
	}
	return fmt.Sprintf("%s: %s", ae.Code, ae.Message)
}

func (ae *AppError) Unwrap() error {
	return ae.Err
}

// NewAppError crea un nuevo error de aplicación
func NewAppError(code, message, details string, err error) *AppError {
	return &AppError{
		Code:    code,
		Message: message,
		Details: details,
		Err:     err,
	}
}

// ============================================
// NETWORKING
// ============================================

// GetLocalIP obtiene la IP local de la máquina
func GetLocalIP() (string, error) {
	addrs, err := net.InterfaceAddrs()
	if err != nil {
		return "", err
	}

	for _, addr := range addrs {
		if ipnet, ok := addr.(*net.IPNet); ok && !ipnet.IP.IsLoopback() {
			if ipnet.IP.To4() != nil {
				return ipnet.IP.String(), nil
			}
		}
	}

	return "", errors.New("no se pudo determinar la IP local")
}

// IsPortAvailable verifica si un puerto está disponible
func IsPortAvailable(port int) bool {
	listener, err := net.Listen("tcp", fmt.Sprintf(":%d", port))
	if err != nil {
		return false
	}
	listener.Close()
	return true
}

// ============================================
// FUNCIONES DE PRUEBA (TESTING)
// ============================================

// MockUser crea un usuario de prueba
func MockUser() map[string]interface{} {
	return map[string]interface{}{
		"id":    "test-" + strconv.FormatInt(time.Now().UnixNano(), 10),
		"email": "test@example.com",
		"name":  "Usuario de Prueba",
		"role":  "reader",
	}
}

// MockBook crea un libro de prueba
func MockBook() map[string]interface{} {
	return map[string]interface{}{
		"id":          "book-" + strconv.FormatInt(time.Now().UnixNano(), 10),
		"title":       "El Principito",
		"author":      "Antoine de Saint-Exupéry",
		"description": "Una obra clásica de la literatura",
		"language":    "es",
		"tags":        []string{"clásico", "literatura", "niños"},
		"format":      "pdf",
	}
}

// Benchmark mide el tiempo de ejecución de una función
func Benchmark(name string, fn func()) time.Duration {
	start := time.Now()
	fn()
	elapsed := time.Since(start)

	log.Printf("Benchmark %s: %v", name, elapsed)
	return elapsed
}

// ============================================
// FUNCIONES DE INICIALIZACIÓN
// ============================================

// InitSystem inicializa el sistema
func InitSystem() error {
	// Crear directorios necesarios
	dirs := []string{
		"./storage",
		"./storage/books",
		"./storage/temp",
		"./logs",
		"./templates",
		"./static",
		"./static/css",
		"./static/js",
		"./static/images",
	}

	for _, dir := range dirs {
		if err := os.MkdirAll(dir, 0755); err != nil {
			return fmt.Errorf("error creando directorio %s: %v", dir, err)
		}
	}

	// Crear archivos de configuración por defecto si no existen
	defaultConfig := Config{
		ServerPort:   ":8080",
		StoragePath:  "./storage",
		MaxFileSize:  10 * 1024 * 1024,
		AllowedTypes: []string{".pdf", ".epub", ".mobi"},
		LogLevel:     "info",
	}

	configData, _ := json.MarshalIndent(defaultConfig, "", "  ")
	SafeWriteFile("config.json", configData, 0644)

	// Crear template por defecto
	createDefaultTemplates()

	return nil
}

func createDefaultTemplates() {
	// Crear templates HTML básicos
	templates := map[string]string{
		"layout.html": `<!DOCTYPE html>
<html>
<head>
    <title>{{.Title}} - Sistema de Libros</title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/static/css/style.css">
</head>
<body>
    <header>
        <h1>Sistema de Gestión de Libros Electrónicos</h1>
        <nav>
            <a href="/">Inicio</a>
            <a href="/books">Libros</a>
            <a href="/login">Login</a>
        </nav>
    </header>
    <main>
        {{template "content" .}}
    </main>
    <footer>
        <p>UIDE - Programación Orientada a Objetos</p>
    </footer>
</body>
</html>`,

		"index.html": `{{define "content"}}
    <h2>Bienvenido al Sistema de Gestión de Libros</h2>
    <p>Sistema desarrollado para la UIDE</p>
    <div class="features">
        <div class="feature">
            <h3>📚 Gestión de Libros</h3>
            <p>Administra tu biblioteca digital</p>
        </div>
        <div class="feature">
            <h3>🔐 Control de Acceso</h3>
            <p>Roles de usuario y permisos</p>
        </div>
        <div class="feature">
            <h3>🔍 Búsqueda Avanzada</h3>
            <p>Encuentra libros fácilmente</p>
        </div>
    </div>
{{end}}`,

		"login.html": `{{define "content"}}
    <h2>Iniciar Sesión</h2>
    <form id="loginForm">
        <div>
            <label>Email:</label>
            <input type="email" id="email" required>
        </div>
        <div>
            <label>Contraseña:</label>
            <input type="password" id="password" required>
        </div>
        <button type="submit">Ingresar</button>
    </form>
    <script src="/static/js/auth.js"></script>
{{end}}`,
	}

	for filename, content := range templates {
		SafeWriteFile(filepath.Join("./templates", filename), []byte(content), 0644)
	}

	// Crear CSS básico
	css := `/* Estilos básicos del sistema */
* {
    margin: 0;
    padding: 0;
    box-sizing: border-box;
}

body {
    font-family: Arial, sans-serif;
    line-height: 1.6;
    color: #333;
    max-width: 1200px;
    margin: 0 auto;
    padding: 20px;
}

header {
    background: #2c3e50;
    color: white;
    padding: 1rem;
    border-radius: 5px;
    margin-bottom: 20px;
}

nav a {
    color: white;
    margin-right: 15px;
    text-decoration: none;
}

nav a:hover {
    text-decoration: underline;
}

.features {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    gap: 20px;
    margin-top: 30px;
}

.feature {
    border: 1px solid #ddd;
    padding: 20px;
    border-radius: 5px;
    text-align: center;
}

form div {
    margin-bottom: 15px;
}

form label {
    display: block;
    margin-bottom: 5px;
}

form input {
    width: 100%;
    padding: 8px;
    border: 1px solid #ddd;
    border-radius: 4px;
}

button {
    background: #3498db;
    color: white;
    padding: 10px 20px;
    border: none;
    border-radius: 4px;
    cursor: pointer;
}

button:hover {
    background: #2980b9;
}

footer {
    margin-top: 40px;
    text-align: center;
    color: #666;
    border-top: 1px solid #ddd;
    padding-top: 20px;
}`

	SafeWriteFile("./static/css/style.css", []byte(css), 0644)
}
