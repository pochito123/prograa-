package models

import (
	"errors"
	"mime"
	"path/filepath"
	"time"
)

type BookFormat string

const (
	FormatPDF  BookFormat = "pdf"
	FormatEPUB BookFormat = "epub"
	FormatMOBI BookFormat = "mobi"
)

type Book struct {
	ID          string     `json:"id"`
	Title       string     `json:"title"`
	Author      string     `json:"author"`
	Description string     `json:"description"`
	Language    string     `json:"language"`
	Tags        []string   `json:"tags"`
	Format      BookFormat `json:"format"`
	FileSize    int64      `json:"file_size"`
	FileName    string     `json:"file_name"`
	UploadedAt  time.Time  `json:"uploaded_at"`
	UploadedBy  string     `json:"uploaded_by"`
	IsActive    bool       `json:"is_active"`

	// Método de encapsulación
	filePath string
}

// Constructor
func NewBook(title, author, description, language, fileName string, tags []string) (*Book, error) {
	if title == "" || author == "" {
		return nil, errors.New("título y autor son requeridos")
	}

	format := getFormatFromFileName(fileName)
	if format == "" {
		return nil, errors.New("formato de archivo no soportado")
	}

	return &Book{
		ID:          generateID(),
		Title:       title,
		Author:      author,
		Description: description,
		Language:    language,
		Tags:        tags,
		Format:      format,
		FileName:    fileName,
		UploadedAt:  time.Now(),
		IsActive:    true,
	}, nil
}

// Getters y Setters
func (b *Book) GetFilePath() string {
	return b.filePath
}

func (b *Book) SetFilePath(path string) {
	b.filePath = path
}

// Métodos
func (b *Book) AddTag(tag string) {
	// Uso de bucles
	for _, existingTag := range b.Tags {
		if existingTag == tag {
			return // Tag ya existe
		}
	}
	b.Tags = append(b.Tags, tag)
}

func (b *Book) RemoveTag(tag string) {
	// Manejo de slices
	newTags := []string{}
	for _, existingTag := range b.Tags {
		if existingTag != tag {
			newTags = append(newTags, existingTag)
		}
	}
	b.Tags = newTags
}

func (b *Book) HasTag(tag string) bool {
	for _, t := range b.Tags {
		if t == tag {
			return true
		}
	}
	return false
}

func (b *Book) UpdateInfo(title, author, description string) {
	if title != "" {
		b.Title = title
	}
	if author != "" {
		b.Author = author
	}
	if description != "" {
		b.Description = description
	}
}

// Helper function
func getFormatFromFileName(fileName string) BookFormat {
	ext := filepath.Ext(fileName)
	mimeType := mime.TypeByExtension(ext)

	switch {
	case ext == ".pdf" || mimeType == "application/pdf":
		return FormatPDF
	case ext == ".epub" || mimeType == "application/epub+zip":
		return FormatEPUB
	case ext == ".mobi" || mimeType == "application/x-mobipocket-ebook":
		return FormatMOBI
	default:
		return ""
	}
}
