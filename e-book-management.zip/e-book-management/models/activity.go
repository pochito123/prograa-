package models

import (
	"time"
)

type ActivityType string

const (
	ActivityLogin      ActivityType = "login"
	ActivityDownload   ActivityType = "download"
	ActivityUpload     ActivityType = "upload"
	ActivityUpdate     ActivityType = "update"
	ActivityDelete     ActivityType = "delete"
	ActivityCreateUser ActivityType = "create_user"
)

type Activity struct {
	ID        string       `json:"id"`
	UserID    string       `json:"user_id"`
	Type      ActivityType `json:"type"`
	Details   string       `json:"details"`
	Timestamp time.Time    `json:"timestamp"`
	IPAddress string       `json:"ip_address,omitempty"`
}

func NewActivity(userID string, activityType ActivityType, details string) *Activity {
	return &Activity{
		ID:        generateID(),
		UserID:    userID,
		Type:      activityType,
		Details:   details,
		Timestamp: time.Now(),
	}
}
